package com.noxtan.pass.aidl;

import com.noxtan.pass.aidl.VaultAccountInfo;

interface INoxtanVaultService {
    boolean isAppLockPinSet();

    boolean isVaultLocked();

    boolean unlockWithPin(String pin);

    void lockVault();

    List<VaultAccountInfo> getAccountsForPackage(String packageName);

    List<VaultAccountInfo> searchAllAccounts(String query);
}